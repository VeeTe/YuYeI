#!/bin/bash
strURL="https://rhymezone.com/r/rhyme.cgi?Word="
strName=$1


strName=${strName,,}

strSearchResult=$(cat ParsedWords | grep "$strName")

if [[ "$strSearchResult" != "$strName" ]]; then


strTransform=${strName/" "/"+"}

strURL+=$strTransform
strURL+="&typeofrhyme=perfect&org1=syl&org2=l&org3y"
echo ".__________________________________________________________________."
echo "| Word was not found in the local storage, downloading definitions.|"
echo "|__________________________________________________________________|"
echo ""

curl $strURL > Rhyme/"$strName"
echo $strURL


FileName=$strName

strNewFile=$FileName


touch RhymeFormatted/$strNewFile


while read strLine; do

case $strLine in
	*"<b><a class=r href="*)
#	echo $strLine
	strTransform=${strLine#*d=}
	strTransform=${strTransform%>*}
	strTransform=${strTransform%>*}
	strTransform=${strTransform%>*}
	strTransform=${strTransform::-1}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
	strTransform=${strTransform/"_"/" "}
		
	echo $strTransform >> RhymeFormatted/$strNewFile
	;;
esac


done < Rhyme/"$FileName"
#fi



strURL="https://api.dictionaryapi.dev/api/v2/entries/en/"
strName1=$strName
strName1=${strName1,,}
strURL+=$strName1
curl $strURL > Dictionary/"$strName1"
echo $strURL

#Parsed words:
touch ParsedWords
echo $strName1 >>ParsedWords
fi
echo ""
echo ""
echo ""
echo "______________"
