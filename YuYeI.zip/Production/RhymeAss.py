import json
import os
import sys
import time

strFileName = sys.argv[1]
strFileName = strFileName.lower()
os.system("./PullAndFormat.sh "+strFileName)
#Document waiting for the file to be pulled, probably can be substituted with checker 
time.sleep(1)
f = open("Dictionary/"+strFileName)
word_dictionary = json.load(f)






strSynonyms_Arr = [[]]
strDefinition_Arr = [[]]

print("")
intCounter1 = 0
while intCounter1 > -1:
	intCounter2 = 0
	try:



		while intCounter2 > -1:
			intCounter3 = 0
			try:
				print("| Part of Speech: " +  json.dumps(word_dictionary[intCounter1]['meanings'][intCounter2]['partOfSpeech']))
				try:
					while intCounter3 > -1:
						
						print("| Definition: " +  json.dumps(word_dictionary[intCounter1]['meanings'][intCounter2]['definitions'][intCounter3]['definition']))

						print("| Sub-Synonyms: " +  json.dumps(word_dictionary[intCounter1]['meanings'][intCounter2]['definitions'][intCounter3]['synonyms']))
								
						
						intCounter3 += 1
				except:
					intCounter3 = -1
				
				
				strSynonyms_Arr[intCounter1].append(json.dumps(word_dictionary[intCounter1]['meanings'][intCounter2]['synonyms']))
				print("|")
				print("| Generalized Synonyms: " + (json.dumps(word_dictionary[intCounter1]['meanings'][intCounter2]['synonyms'])))
				print("|--")
		
				intCounter2+=1
			except:
				intCounter2 = -1
		
		strTester = word_dictionary[intCounter1]
		intCounter1 += 1
		strSynonyms_Arr.append([])
		print("|")
		print("| Definition: {_" + str(intCounter1) + "_}")
		print("|_________")
		print("")
		print("")
	except:
		strDefinition_Arr.pop()
		intCounter1 = -1




f = open("RhymeFormatted/"+strFileName, "r")
rhyme_dictionary = f.read()
rhyme_list = rhyme_dictionary.split("\n")
f.close()
print("")
print("Words that rhyme with it are: ")
print(rhyme_list)
print("")
print("")
print("")
print("")
